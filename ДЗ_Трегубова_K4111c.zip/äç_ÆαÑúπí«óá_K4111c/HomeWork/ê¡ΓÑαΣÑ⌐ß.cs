﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HomeWork
{
    class Интерфейс
    {
        private List<Абстрактный класс> videoCamList;
        internal static Интерфейс instance;

        public Интерфейс(int oplatit)
        {
            videoCamList = new List<Абстрактный класс>();
            createOpl(oplatit);
        }

        internal object startProcess(int v)
        {
            throw new NotImplementedException();
        }

        internal void printReport()
        {
            throw new NotImplementedException();
        }

        private void createOpl(int num)
        {
            for (int i = 0; i < num; i++)
            {
                videoCamList.Add(new Способоплаты() { name = "Забронировать" + (i + 1) });
            }
        }

        public Dictionary<string, int> returnCamerasData()
        {
            Dictionary<string, int> result = new Dictionary<string, int>();
            Отменить  Команда;
            foreach (Способоплаты invoker in videoCamList)
            {
                Команда = new Отменить(invoker);
                result.Add(invoker.name, Команда.returnCapacity());
            }

            return result;
        }
    }
}

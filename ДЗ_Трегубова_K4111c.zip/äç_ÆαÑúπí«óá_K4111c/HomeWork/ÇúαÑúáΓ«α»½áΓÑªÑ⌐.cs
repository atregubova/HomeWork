﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HomeWork

{
    class Агрегаторплатежей
    {
        public static Random r;
    static void Main()
    {
        r = new Random();

        Дополнительно ctrl = Дополнительно.instance;
            ctrl.startProcess(4);
            ctrl.printReport();
            Console.ReadLine();
        }
}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HomeWork
{
    class  Отменить : Оплатауслуги
    {
        private Способоплаты  Способоплаты;

    public Отменить(Способоплаты Способоплаты)
    {
        this.Способоплаты = Способоплаты;
    }
        public int returnCapacity()
        {
            return Способоплаты.returnCapacity() / 2;
        }
    }
}

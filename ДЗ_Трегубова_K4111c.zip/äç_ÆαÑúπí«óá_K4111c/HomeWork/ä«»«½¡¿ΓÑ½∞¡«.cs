﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HomeWork
{
      class Дополнительно
    {
        
        private static Дополнительно ctrl;

        public static Дополнительно instance
        {
            get
            {
                if (ctrl == null) ctrl = new Дополнительно();
                return ctrl;
            }
        }

        Интерфейс Добавитьманикюр;
        Dictionary<string, int> streamData;
        public void startProcess(int videoCamNum)
        {
            Добавитьманикюр = new Дополнительно(videoCamNum);
            streamData = Добавитьманикюр.returnCamerasData();
        }

        public void printReport()
        {
            foreach (KeyValuePair<string, int> k in streamData)
            {
                Console.WriteLine("Дополнительно: {0}, Добавить маникюр: {1}", k.Key, k.Value);
            }
        }

    }
}
